WIP Python client for official Notion API (now in public beta)

For now just internal integrations.

Feel free to contribute.

MIT license.
